package com.planetickets.validator.user;

/**
 * Created by user on 29.05.2017.
 */
public interface UserValidationMessages {

    String WRONG_FIRST_NAME = "WRONG FIRST NAME";

    String EMPTY_USERNAME_FIELD = "EMPTY USERNAME FIELD";
    String USERNAME_ALREADY_EXIST = "USERNAME ALREADY EXISTS";

    String WRONG_EMAIL = "WRONG EMAIL";
    String EMPTY_EMAIL = "EMPTY EMAIL";

}
