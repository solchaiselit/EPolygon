package com.planetickets.validator.user;

/**
 * Created by user on 29.05.2017.
 */
public class UserException extends Exception {

    public UserException(String message) {
        super(message);
    }
}

