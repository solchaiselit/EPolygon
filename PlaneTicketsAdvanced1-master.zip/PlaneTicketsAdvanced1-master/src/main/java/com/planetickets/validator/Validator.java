package com.planetickets.validator;

/**
 * Created by user on 29.05.2017.
 */
public interface Validator {

    void validate(Object o) throws Exception;



}
